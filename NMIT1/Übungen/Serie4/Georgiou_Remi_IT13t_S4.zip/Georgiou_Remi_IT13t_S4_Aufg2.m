% Funktion Georgiou_Remi_IT13t_S4_Aufg2(func,a,b,tol)
% Implementation des Bijektionsverfahrens mit einem iterativen Algorithmus.
% Das Verfahren berechnet auf numerische Weise die Nullstelle einer
% stetigen Funktion in einem gegebenen Intervall, vorausgesetzt 
% der Nullstellensatz von Bolzano sagt eine Nullstelle innerhalb des
% Intervalls voraus.
%
% Paramter:
% func - Handle einer anonymen Matlab-Funktion
% a - linke Intervallgrenze
% b - rechte Intervallgrenze
% tol - Toleranz
%
% Die Funktion hat 3 R�ckgabewerte : root,xit,n
% root ist die approximierte Nullstele.
% xit enth�lt die N�herungswerte f�r die gesuchte Nullstelle.
% n speichert die Anzahl Iterationen.
% Beispiel eines Funktionsaufrufes:
% [root,xit,n] = Georgiou_Remi_IT13t_S4_Aufg2(@(x) cos(x).*sin(x),-1,pi,1e-6)

function[root,xit,n] = Georgiou_Remi_IT13t_S4_Aufg2(func,a,b,tol)

if abs(a-b) == 0,
   error('Invalid intervall'); 
end

% zus�tzliches Abbruchkritierum, maximale Anzahl Iterationen
maxIterations = 100;
xit = [];
n = 0;

while (abs(a-b) > tol && n < maxIterations)
    xit = [xit func((a+b)/2)];
    if func((a+b)/2) * func(a) <= 0,
        b = (a+b)/2;
    else
         a = (a+b)/2;
    end
    n = n+1;
end
root = xit(length(xit));
end