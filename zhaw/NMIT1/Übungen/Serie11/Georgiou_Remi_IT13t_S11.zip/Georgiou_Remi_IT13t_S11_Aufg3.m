% Funktion Georgiou_Remi_IT13t_S11_Aufg3
% Aufruf: Georgiou_Remi_IT13t_S11_Aufg3()

function[] = Georgiou_Remi_IT13t_S11_Aufg3()
    clc; clear all; format long;
 
    syms x y; 
    f1 = x^2/186^2 - y^2/(300^2-186^2)-1;
    f2 = (y-500)^2/279^2 - (x-300)^2/(500^2-279^2)-1;
    f = [f1; f2]
   
    % a) grafische L�sung des Gleichungssystems
    hold on
    ezplot(f1,[-2000,2000,-2000,2000])
    ezplot(f2,[-2000,2000,-2000,2000])
    legend('f1(x,y)','f2(x,y)','Location','northoutside');
    title('Hyperbelf�rmige Ortskurven');
    grid on;
 
    % 2. Paramter: abgelesener Schnittpunkt
    x0 = Newton(f,[200; 200])
    plot(x0(1), x0(2), 'ro','LineWidth',2) 
    x0 = Newton(f,[-100; 100])
    plot(x0(1), x0(2), 'ro','LineWidth',2)
    x0 = Newton(f,[-1100; 1500])
    plot(x0(1), x0(2), 'ro','LineWidth',2)
    x0 = Newton(f,[600; 700])
    plot(x0(1), x0(2), 'ro','LineWidth',2)
    hold off
end

% b) Implementation des Newtonschen Verfahren f�r nichtlineare Systeme
function x0 = Newton(f,x0)
    x = sym('x');
    y = sym('y');
    old = [x; y];           
    Df = jacobian(f)
 
    tol = 1e-5;
    d0 = 1;
    n = 0
    while norm(d0,2) > tol
        Dfv = subs(Df,old,x0);   % Df mit xn ausgewertet
        fv = subs(f,old,x0);     % f mit xn ausgewertet
        d0 = double(-Dfv\fv);
        x0 = x0 + d0
        n = n + 1
        disp('---');
    end
end
