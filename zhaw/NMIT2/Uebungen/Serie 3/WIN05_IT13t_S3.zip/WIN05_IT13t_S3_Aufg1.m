% NMIT3 - Serie 3, Aufgabe 1
% @author R�mi Georgiou (georgrem), Andr� Stocker (stockan1)

format compact;format short;clc;

f = @(x) log(x.^2);
syms x
fdiff = matlabFunction(diff(f,x,2));

a = 1;
b = 2;
MAX_FEHLER = 1e-5;

maxIntervall = max(abs(fdiff(a)), abs(fdiff(b)));
% Trapezregel
hTrapez = sqrt(12 * MAX_FEHLER /((b-a) * maxIntervall));
nTrapez = ceil((b-a)/hTrapez);

% Rechteckregel
hRechteck = sqrt(24 * MAX_FEHLER /((b-a) * maxIntervall));
nRechteck = ceil((b-a)/hRechteck);

% Simpsonregel
fdiff = matlabFunction(diff(f,x,4));
maxIntervall = max(abs(fdiff(a)),(fdiff(b)));
hSimpson = (2880 * MAX_FEHLER /((b-a) * maxIntervall)).^(1/4);
nSimpson = ceil((b-a)/hSimpson);

fprintf('Integrationsverfahren \t Schrittweite h \t Subintervalle n \n')
fprintf('************************************************************\n')
fprintf('Rechteckregel \t\t\t %.5f \t\t\t %i \n', hRechteck, nRechteck)
fprintf('Trapezregel \t\t\t %.5f \t\t\t %i \n', hTrapez, nTrapez)
fprintf('Simpsonregel \t\t\t %.5f \t\t\t %i \n', hSimpson, nSimpson)